@extends('layouts.app')

@section('content')

    <div class="alert alert-success" role="alert" >
        Bienvenido a la página principal
    </div>
@endsection